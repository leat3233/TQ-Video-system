
window.hm_url = "https://hm.baidu.com/hm.js?427f72ce75b0677eb10f24419484eb80";
window.line_1 = "https://26e4bc2ed9eb.com/";
window.line_2 = "https://a3d3h.com/";
window.line_3 = "https://f9ce934d307a.com/";
window.default_line = "https://26e4bc2ed9eb.com/";
