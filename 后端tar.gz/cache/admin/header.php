<header>
    <div class="fl">
        <a href=""><img src="<?php echo IMG ?>/bklogo.png" /></a>
    </div>
    <div class="fr mart11">
        <!--<a href="<?php echo INDEX ?>" target="_blank" class="btn btn3 gohome"><i class="fa fa-home"></i> 前台首页</a>-->
    	<a href="javascript:;" class="logout btn btn4"><i class="fa fa-sign-out"></i> 退出</a>
    </div>
    <div class="clear"></div>
</header>