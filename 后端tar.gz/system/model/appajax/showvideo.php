<?php 
    if(!defined('CW')){exit('Access Denied');}
    $db = functions::db();
    $tel = CW('gp/tel');
    $vid = CW('gp/id');
    
?>