
<?php 
    header('Content-Type: application/json');
    if(!defined('CW')){exit('Access Denied');}
    $db = functions::db();
    $type = CW('gp/type');
    $tel = CW('gp/tel');

    $page = CW('gp/page') ? CW('gp/page') : 0;

    $where = '';
    $pagestart = $page*APPSIZE;
    $order = 'id desc';
    
    if($type=='0'){
       $order = 'rand()';
    }else if($type=='1'){
        $order = 'id desc';
    }else if($type=='2'){
        $order = 'id desc';
    }else{
        $order = 'id desc';
        $where = "city like '%{$type}%'";
    }

    $more = array();
    $datas = $db->query('tuan','',$where,$order,"{$pagestart},".APPSIZE);
    foreach($datas as $data){
           
      $desc = $db->query("select descs from users where tel='{$data['tel']}' limit 1");
      array_push($more,array(
        'id'=>$data['id'],
        'tel'=>$data['tel'],
        'nickname'=>$data['nickname'],
        'shengao'=>$data['shengao'],
        'zhiye'=>$data['zhiye'],
        'tizhong'=>$data['tizhong'],
        'city'=>$data['city'],
        'nianling'=>$data['nianling'],
        'xingbie'=>$data['xingbie'],
        'wx'=>$data['wx'],
        'desc'=>$desc[0]['descs'],
        'cover'=>explode('|',$data['imglist'])[0],
      ));
    }
   
    //输出
    if(!$more){
        echo json_encode(array(
            'more'=>'over',
        ));return;
    }
    echo json_encode(array(
        'more'=>$more,
        'page'=>intval($page)+1
    ));
    

?>


