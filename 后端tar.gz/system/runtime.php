<?php
    if(!defined('CW')){exit('Access Denied');}
    require "adapter/adapter.php";
    require "config/global_config.php";
    require "library/file.php";
    require "library/functions.php";
    require "system.php";
    require "library/dbserver.php";
    
    
?>